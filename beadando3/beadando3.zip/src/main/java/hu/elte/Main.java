package hu.elte;

import hu.elte.view.Game;

public class Main {

    public static void main(String[] args) {
        Game game = new Game();
        
        
  /*      String[] names = new String[]{"Peter", "Adrienne", "Ethan", "Jane", "Paul", "Geoffrey", "Joe", "Laura"};
        try {
            Random random = new Random();
            HighScoreManager highScores = new HighScoreManager(3);
            System.out.println(highScores.getSortedHighScores());
            
            highScores.putHighScore(names[random.nextInt(names.length)], random.nextInt(100));
            System.out.println(highScores.getSortedHighScores());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }*/
    }
}
