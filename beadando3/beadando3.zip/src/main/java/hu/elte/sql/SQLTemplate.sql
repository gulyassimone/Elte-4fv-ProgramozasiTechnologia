/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Simone Gulyas
 * Created: 2021. máj. 22.
 */
use highscores;

drop table HIGHSCORES;

create table HIGHSCORES (
    TIMESTAMP TIMESTAMP,
    NAME VARCHAR(50),
    SCORE INT
);

select * from HIGHSCORES;   -- check the results
